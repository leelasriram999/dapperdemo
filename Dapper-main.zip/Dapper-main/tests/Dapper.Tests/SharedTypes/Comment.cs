﻿namespace Dapper.Tests
{
    public class Comment
    {
        public int Id { get; set; }
        public string? CommentData { get; set; }
    }
}
