﻿namespace Dapper.Tests
{
    internal enum AnEnum
    {
        A = 2,
        B = 1
    }

    internal enum AnotherEnum : byte
    {
        A = 2,
        B = 1
    }
}
