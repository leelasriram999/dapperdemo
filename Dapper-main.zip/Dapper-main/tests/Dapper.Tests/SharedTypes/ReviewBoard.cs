﻿namespace Dapper.Tests
{
    public class ReviewBoard
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public User? User1 { get; set; }
        public User? User2 { get; set; }
        public User? User3 { get; set; }
        public User? User4 { get; set; }
        public User? User5 { get; set; }
        public User? User6 { get; set; }
        public User? User7 { get; set; }
        public User? User8 { get; set; }
        public User? User9 { get; set; }
    }
}
