﻿namespace Dapper.Tests
{
    public class Address
    {
        public int AddressId { get; set; }
        public string? Name { get; set; }
        public int PersonId { get; set; }
        public Index? Index { get; set; }
    }
}
