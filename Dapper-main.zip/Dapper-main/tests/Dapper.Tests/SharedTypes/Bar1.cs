﻿namespace Dapper.Tests
{
    public class Bar1
    {
        public int BarId;
        public string? Name { get; set; }
    }
}
