﻿namespace Dapper.Tests
{
    public class Foo1
    {
        public int Id;
        public int BarId { get; set; }
    }
}
