﻿using System.Runtime.CompilerServices;
#if !STRONG_NAME
[assembly: InternalsVisibleTo("Dapper.Tests")]
#endif
