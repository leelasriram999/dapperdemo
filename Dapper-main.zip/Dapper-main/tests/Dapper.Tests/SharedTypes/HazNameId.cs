﻿namespace Dapper.Tests
{
    public class HazNameId
    {
        public string? Name { get; set; }
        public int Id { get; set; }
    }
}
