﻿namespace Dapper.Tests
{
    public class Index
    {
        public string? Id { get; set; }
    }
}
